class SavedGame:
    def __init__(self):
        self.won = True
        self.name = 'Complete'
        self.credits = 23150
        self.world = 'championship'
        self.race = 5
        self.upgrades = [0,0,0,0]
        self.ships = [1,1,1,1,1,1]
        self.cpu1Credits = 23150
        self.cpu1Upgrades = [0,0,0,0]
        self.cpu2Credits = 20150
        self.cpu2Upgrades = [0,0,0,0]
        self.cpu3Credits = 23150
        self.cpu3Upgrades = [0,0,0,0]
        self.cpu4Credits = 22150
        self.cpu4Upgrades = [0,0,0,0]
        self.cpu5Credits = 23150
        self.cpu5Upgrades = [0,0,0,0]
